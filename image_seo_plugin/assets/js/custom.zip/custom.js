
//   var modal = document.getElementById("myModal");

// // Get the button that opens the modal
// var btn = document.getElementById("myBtn");

// // Get the <span> element that closes the modal
// var span = document.getElementsByClassName("close")[0];

// // When the user clicks on the button, open the modal
// btn.onclick = function() {
//   modal.style.display = "block";
// }

// // When the user clicks on <span> (x), close the modal
// span.onclick = function() {
//   modal.style.display = "none";
// }

// // When the user clicks anywhere outside of the modal, close it
// window.onclick = function(event) {
//   if (event.target == modal) {
//     modal.style.display = "none";
//   }
// }

// $("input#keyword").keyup(function() {
//   if ($(this).val().length > 2) {
//     $("#datafetch").show();
//   } else {
//     $("#datafetch").hide();
//   }
// });

// function copyToClipboard(element) {
//   var $temp = $("<input>");
//   $("body").append($temp);
//   $temp.val($(element).text()).select();
//   document.execCommand("copy");
//   $temp.remove();
// }


get_data_ajax = function (e) {
  var ajaxurl = localajax.ajaxurl;
  var action = jQuery(e.target).data('action');
  call_action = 1; 
  if (action == 'update') {
    call_action = 2;
  }
 
  jQuery.ajax({
    url: localajax.ajaxurl, // this will point to admin-ajax.php
    dataType: 'html',
    type: 'POST',
    data: {
      'action': 'data_fetch',
      'btn_action': call_action
    },
    success: function (response) {
      console.log(response);
    }
  });

}


jQuery(document).ready(function () {


  // var get_data_ajax = function(btn){
  //   alert(btn.this);
  // }

  // get_data_ajax();


  // jQuery(".find_thumbnail").click(function () {
  //   var ajaxurl = localajax.ajaxurl;
  //   jQuery.ajax({
  //     url: localajax.ajaxurl, // this will point to admin-ajax.php
  //     dataType: 'html',
  //     type: 'POST',
  //     data: {
  //       'action': 'data_fetch',
  //       'btn_action': '2'
  //     },
  //     success: function (response) {
  //       console.log(response);
  //     }
  //   });
  // });
  //FInd 
  // jQuery(".find").click(function () {
  //   var ajaxurl = localajax.ajaxurl;
  //   jQuery.ajax({
  //     url: localajax.ajaxurl, // this will point to admin-ajax.php
  //     dataType: 'html',
  //     type: 'POST',
  //     data: {
  //       'action': 'data_fetch',
  //       'btn_action' : '1'
  //     },
  //     success: function (response) {
  //       console.log(response);
  //     }
  //   });
  // });


});